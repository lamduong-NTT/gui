<?php

// FreePBX crams their ampuser class directly into $_SESSION
require_once('libraries/ampuser.class.php');

// Start session when needed (which should be always)
if (strlen(session_id()) == 0) {
	session_start();
}

// Handle logout URL: /admin/config.php?logout=true
if (array_key_exists('logout', $_REQUEST) && $_REQUEST['logout'] == 'true') {
	unset($_SESSION['AMP_user']);
	header("Location: config.php");
	exit;
}

$access_denied = null;

// Handle login
if (!array_key_exists('AMP_user', $_SESSION) &&
	array_key_exists('username', $_POST) &&
	array_key_exists('password', $_POST)) {
	// call bootstrap.php through freepbx.conf
	if (!@include_once(getenv('FREEPBX_CONF') ? getenv('FREEPBX_CONF') : '/etc/freepbx.conf')) {
		 include_once('/etc/asterisk/freepbx.conf');
	}
	$user = new ampuser($_POST['username']);
	if ($user->checkPassword(sha1($_POST['password']))) {
		$_SESSION['AMP_user'] = $user;
		header("Location: config.php");
		exit;
	} else {
		$access_denied = _('Invalid Username or Password');
	}
}

// Show administration panel if we have a valid user
if (array_key_exists('AMP_user', $_SESSION)) {
	include('config.php');
	exit;
}
// Set language
$lang = array_key_exists('l', $_REQUEST) ?
	$_REQUEST['l'] : (array_key_exists('lang', $_COOKIE) ?
		$_COOKIE['lang'] : 'en_US');
setcookie('lang', $lang, -1, null);
setlocale(LC_ALL,  $lang);
putenv("LANGUAGE=$lang");
$domain = 'amp';
bindtextdomain($domain,'i18n');
bind_textdomain_codeset($domain, 'utf8');
textdomain($domain);

// Show login screen
?>
<!DOCTYPE html>
<html>
<head>
<title>CompletePBX Administration</title>
<meta http-equiv="Content-Type" content="text/html;charset=utf-8">
<link rel="shortcut icon" href="favicon.ico">
<style type="text/css">
html, body {
	margin: 0px;
	padding: 0px;
	font-family: sans-serif;
	font-size: 16px;
	height: 100%;
}
div.container {
	display:table;
	width: 100%;
	height: 100%;
}
div.header {
	display: table-row;
	height: 29px;
}
div.header > div {
	height: 29px;
	border: 1px solid #aed0ea;
	background-color: #deedf7;
	background: url(images/XorcomLogo.png) no-repeat 10px center, linear-gradient(#f1f7fb, #deedf7);
}
div.language ul {
	position: absolute;
	right: 0px;
	text-align: left;
	list-style: none;
	border: 1px solid #ddd;
	background: #f2f5f7;
	margin: 0;
	padding: 0;
}
div.language:hover ul { display: block; }
div.language ul { display: none; }
div.header ul a {
	display: block;
	padding: 5px 10px;
	color: #2e6e9e;
	text-decoration: none;
	font-weight: normal;
	line-height: 1.5em;
	font-size: 11px;
}
div.header ul a:hover {
	color: #fff;
	background-color: #c1d6e3;
	background: linear-gradient(#0a5689, #c1d6e3);
}
.button {
	font-size: 12px;
	cursor: pointer;
	text-align: center;
	display: inline-block;
	border: 1px solid #78b0d0;
	border-image: linear-gradient(#78b0d0, #f1f4f6) 1;
	background-color: #eff3f5;
	background: linear-gradient(#b1d0e1, #eff3f5);
	line-height: 23px;
	height: 23px;
	color: #000;
	font-weight: bold;
	margin: 2px 5px;
	padding: 0 1em;
}
.button:hover, .button:focus {
	color: #fff;
	border: 1px solid #2e89bd;
	border-image: linear-gradient(#2e89bd, #f4f8fb) 1;
	background-color: #0a5689;
	background: linear-gradient(#0a5689, #c1d6e3);
}
input.button { line-height: 11px; }
div.body {
	display: table-cell;
	height: 100%;
	text-align: center;
	vertical-align: middle;
}
div.body > p { color: red; }
div.language { float: right; }
div.footer {
	display: table-row;
	height: 140px;
	vertical-align: bottom;
	color: #666;
	font-size: 10px;
	text-align: center;
	background: url(images/oem-footer.png) center 12px no-repeat;
}
div.footer a {
	color: #666;
	text-decoration: none;
}
div.footer a:hover {
	color: #999;
}
div.footer hr { margin-bottom: 100px; }
hr {
	background-color: #deedf7;
	border: 1px solid #aed0ea;
	height: 3px;
	border-radius: 5px;
}
input[type="text"], input[type="password"] {
	padding: 10px;
	height: 1em;
	line-height: 1em;
	width: 300px;
	font-size: 0.8em;
	border: 1px solid #ccc;
	margin-bottom: 1em;
}
</style>
</head>
<body>
<div class="container">
	<div class="header">
		<div>
			<div class="language button">
				<?php echo _('Language'); ?>
				<ul>
					<li><a href="?l=en-US">English</a></li>
					<li><a href="?l=bg_BG">български</a></li>
					<li><a href="?l=zh_CN">中文</a></li>
					<li><a href="?l=de_DE">Deutsch</a></li>
					<li><a href="?l=es_ES">Español</a></li>
					<li><a href="?l=fr_FR">Français</a></li>
					<li><a href="?l=he_IL">עברית</a></li>
					<li><a href="?l=it_IT">Italiano</a></li>
					<li><a href="?l=ja_JP">日本語</a></li>
					<li><a href="?l=hu_HU">Magyar</a></li>
					<li><a href="?l=pt_PT">Português</a></li>
					<li><a href="?l=pt_BR">Português do Brasil</a></li>
					<li><a href="?l=ru_RU">Русский</a></li>
					<li><a href="?l=ro_RO">Română</a></li>
					<li><a href="?l=sv_SE">Svenska</a></li>
				</ul>
			</div>
		</div>
	</div>
	<div class="body">
		<p><?php echo $access_denied; ?></p>
		<form method="post">
			<p><?php echo _('To get started, please enter your credentials:'); ?></p>
			<input type="text" name="username" placeholder="<?php echo _('username'); ?>"/><br/>
			<input type="password" name="password" placeholder="<?php echo _('password'); ?>"/><br/>
			<input type="submit" value="<?php echo _('Login'); ?>" class="button"/>
		</form>
	</div>
	<div class="footer">
		<hr/>
			<span>Powered by <a href="http://www.xorcom.com/" target="blank">Xorcom</a><br/>
			&reg; Copyright 2011 - 2015  <a href="http://www.freepbx.org/copyright.html" target="_blank">Sangoma Technologies.</a> All Rights Reserved.<br/>
			FreePBX is a <a href="http://www.freepbx.org/copyright.html" target="_blank">Registered Trademark</a> of Sangoma Technologies. All Rights Reserved.</span>
	</div>
</div>
</body>
</html>
