<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="shortcut icon" href="favicon.ico"/>
<title>Xorcom CompletePBX</title>
<style type="text/css">
html, body {
	margin: 0px;
	padding: 0px;
	font-family: sans-serif;
	font-size: 12px;
}
body {
	background: linear-gradient(#ededef, #fff) no-repeat, #fff;
}
div.landing, div.buttons, div.footer {
	margin: 0 auto;
	width: 958px;
}
div.landing {
	height: 382px;
	background: url(images/red_wave.jpg) left bottom no-repeat, #fff;
}
div.buttons {
	height: 261px;
	background: #e6e7e8;
}
div.footer {
	height: 84px;
	line-height: 84px;
	background: #d5d7d9;
	border-top: 2px solid #fff;
	color: #666;
	text-align: center;
}
div.footer span {
	display: inline-block;
	vertical-align: middle;
	line-height: 1.3em;
}
div.footer a {
	color: #666;
	text-decoration: none;
}
div.footer a:hover {
	color: #999;
}
div.landing a {
	margin: 0 auto;
	display: block;
}
div.landing a:nth-child(1) {
	width: 255px;
	height: 83px;
	padding-top: 25px;
	background: url(images/Xorcom_logo.jpg) left bottom no-repeat;
}
div.landing a:nth-child(2) {
	width: 250px;
	height: 250px;
	background: url(images/complete-pbx.png) no-repeat;
}
div.buttons { text-align: center; }
div.buttons a {
	margin: 0 16px;
	width: 150px;
	display: inline-block;
	height: 160px;
	text-decoration: none;
	font-size: 14px;
	font-weight: bold;
	color: #000;
	vertical-align:bottom;
	line-height:336px;
	white-space: nowrap;
	text-align: center;
}

div.buttons a:nth-child(1) { background: url(images/administration.jpg) center top no-repeat; }
div.buttons a:nth-child(2) { background: url(images/sbc.jpg) center top no-repeat; }
div.buttons a:nth-child(3) { background: url(images/my_extension.jpg) center top no-repeat; }
div.buttons a:nth-child(4) { background: url(images/my_switchboard.jpg) center top no-repeat; }
div.buttons a:nth-child(5) { background: url(images/statistics.jpg) center top no-repeat; }
div.buttons a:hover { background-position: center -191px; }
<?php
if (!file_exists('/etc/sems/sems.conf')) {
	echo 'div.buttons a:nth-child(2) { display: none; }' . PHP_EOL;
}
?>
</style>
</head>
<body>
<div class="landing">
	<a href="http://www.xorcom.com" target="_blank" title="Xorcom website"></a>
	<a href="http://www.xorcom.com/products/product-catalog/pbx-appliances/completepbx" target="_blank" title="Complete PBX"></a>
</div>
<div class="buttons">
	<a href="/admin/cpbx-config.php" target="_blank" title="Administration">Administration</a><!--
	--><a href="/" target="_blank" title="CompleteSBC">CompleteSBC</a><!--
	--><a href="/recordings" target="_blank" title="My Extension">My Extension</a><!--
	--><a href="/fop2" target="_blank" title="My Switchboard">My Switchboard</a><!--
	--><a href="/xcs-ams" target="_blank" title="Call Center Statistics">Call Center Statistics</a>
</div>
<div class="footer">
	<span>Powered by <a href="http://www.xorcom.com/" target="blank">Xorcom</a><br/>
	&reg; Copyright 2011 - 2015  <a href="http://www.freepbx.org/copyright.html" target="_blank">Sangoma Technologies.</a> All Rights Reserved.<br/>
	FreePBX is a <a href="http://www.freepbx.org/copyright.html" target="_blank">Registered Trademark</a> of Sangoma Technologies. All Rights Reserved.</span>
</div>
<script type="text/javascript">document.querySelector('div.buttons a:nth-child(2)').protocol = "https:";</script>
</body>
</html>
