#!/bin/bash

# OUTPUT

if grep 'debug' /installed-version
then
  echo "SKIPPING THE DEFAULT RUN OF FIRSTBOOT"
  sleep 5
  exit 0
else
  echo "STARTING PBX FIRST BOOT"
fi

log_info(){
  echo "${@}" >> /dev/tty8
}

# LOGGING TO TTY8 and logfile
ORIGCONSOLE=$(fgconsole)
echo "starting on console 8, myconsole = ${ORIGCONSOLE}"
sleep 1
chvt 8
set -x -v
exec > /var/log/pbx/install/firstboot.log
exec 2>&1

#INCLUDING stringent.sh
# stringent.sh copyright michael potter 2008

# stringent.sh is intended to reduce the problems associated with
# using bash by turning on bash options that make errors more
# apparent.  This will not eliminate problems and I am sure there
# is some case where some problem will be made worse.
# USE AT YOUR OWN RISK.

set -o errexit	# errexit first
set -o nounset
set -o pipefail    # if you fail on this line, get a newer version of bash.

function traperr
{
   declare -i i;
   declare -i nestlevel;
   declare Message=${1:-""}

   nestlevel=${#FUNCNAME[@]}

   if (( $nestlevel <= 2 ))
   then
      echo "ERROR: ${BASH_SOURCE[1]}:${BASH_LINENO[0]} $Message" >&2
   else
      echo "ERROR: ${FUNCNAME[1]}(${BASH_SOURCE[1]}:~${BASH_LINENO[0]}) $Message" >&2
      for (( i = 2 ; i < $nestlevel ; i++ ))
      do
         echo "      ${FUNCNAME[$i]}(${BASH_SOURCE[$i]}:~${BASH_LINENO[($i-1)]})" >&2
      done
   fi
   # if BASH_SUBSHELL is 0, then script will exit anyway.
   if (( $BASH_SUBSHELL >= 3 ))
   then
      kill $$
   fi
   echo -e "Some firstboot error occured, and the system is not properly setup.\nCheck to see if you have internet access and re-run /etc/pbx_first_boot.sh\nPress ctrl-alt-f1 to continue" >> /dev/tty8
   exit 1
}

function traperrsimple
{
   # Use this function if the above function fails
   echo "ERROR: ${BASH_SOURCE[0]} ${LINENO}" >&2
   # if BASH_SUBSHELL is 0, then script will exit anyway.
   if (( $BASH_SUBSHELL >= 1 ))
   then
      kill $$
   fi
}

set -o errtrace
trap traperr ERR

function errexiton
{
   set -o errexit
   trap traperr ERR
}

function errexitoff
{
   set +o errexit
   trap '' ERR
}
#END INCLUDE

log_info "Testing for license CPBX"
INTERFACE=$(ip route show | awk ' /^default/ { print $5 }')
MACADDR=$(ip -o link show ${INTERFACE} | awk '/link/ {print $13}')
MACHASH=$(echo -en ${MACADDR} | md5sum - | awk '/-/ {print $1}')
ARCH=$(uname -m)
FREEPBXVERS=$(head -n 1 /etc/schmooze/pbx-version)
INSTALLTYPE=$(cat /installed-version | sed -e 's/.*kickstart-\([^.]*\).*/\1/')
BRAND=$(head -n 1 /etc/schmooze/pbx-brand)
BRAND_RETURN=$(curl -k -s -m 30 -A "FreePBX Firstboot ${BRAND}-${FREEPBXVERS} ${ARCH} ${INSTALLTYPE}" } https://push2.schmoozecom.com/deployment/brand)
MYBRAND=$(echo ${BRAND_RETURN} | python -c 'import simplejson as json,sys;obj=json.loads(sys.stdin.read());print obj["brand"]')
if [[ -n ${MYBRAND} ]]
then
  echo ${MYBRAND} > /etc/schmooze/pbx-brand
fi
UARETURN=$(curl -s -m 30 -A "FreePBX Firstboot ${BRAND}-${FREEPBXVERS} ${ARCH} ${INSTALLTYPE}"  --data mac=${MACADDR} --data mhash=${MACHASH} http://kickstart.freepbxdistro.org/install-log/)

echo ${UARETURN} | grep 'passed'
log_info " CPBX Test Passed"

errexitoff

# Enable modules that in 2.11 are not being enabled from the RPM
sudo -u asterisk /var/lib/asterisk/bin/module_admin enable fw_ari

# pull in all freepbx modules and load them
log_info ""
log_info "Updating all FreePBX modules. This can take a couple of minutes."
sudo -u asterisk /var/lib/asterisk/bin/module_admin installall
sudo -u asterisk /var/lib/asterisk/bin/module_admin uninstall cxpanel
sudo -u asterisk /var/lib/asterisk/bin/module_admin install cxpanel
sudo -u asterisk /var/lib/asterisk/bin/module_admin installall

# Install Commercial modules and reload
log_info ""
log_info "Enabling FreePBX Commercial modules. This can take a couple of minutes."
sudo -u asterisk /var/lib/asterisk/bin/module_admin download sysadmin
sudo -u asterisk /var/lib/asterisk/bin/module_admin install sysadmin
sudo -u asterisk /var/lib/asterisk/bin/module_admin --repos commercial installall
sudo -u asterisk /var/lib/asterisk/bin/module_admin --repos commercial installall

# Write out apache conf.d files
/etc/init.d/incrond restart
touch /var/spool/asterisk/sysadmin/portmgmt_setup

# Reload FreePBX
log_info ""
log_info "Reloading FreePBX with all new modules now"
/usr/local/sbin/amportal chown
sudo -u asterisk /var/lib/asterisk/bin/retrieve_conf
sudo -u asterisk /var/lib/asterisk/bin/module_admin reload

# Restart Asterisk to load all the modules.
log_info ""
log_info "Restarting Asterisk to load all the new modules now"
/usr/local/sbin/amportal restart

errexiton

log_info ""
log_info "Running updatedb to update DB for locate command. This can take a minute."
rm -rf /tmp/*
updatedb

# if we've made it to this point, things have worked (minus the error exit stuff)

# Remove the entry from firstboot
log_info ""
log_info "Firstboot has finished, removing firstboot script"
rm -rf /etc/pbx_first_boot.sh
sed -i '/\/etc\/pbx_first_boot.sh/d' /etc/rc.d/rc.local
rpm -e distro-motd-fpbx
rpm -ivh /opt/distro-motd-xorcom-1.0.0-37.shmz65.1.5.noarch.rpm
cp -Rv /opt/cpbxbranding.tar.gz /var/www/html/admin/modules
cp -Rv /opt/routing_groups.tar.gz /var/www/html/admin/modules
cd /var/www/html/admin/modules
tar -vzxf cpbxbranding.tar.gz
tar -vzxf routing_groups.tar.gz
#install moudle 
/usr/local/sbin/amportal a ma install routing_groups
/usr/local/sbin/amportal a ma install cpbxbranding
cp -Rv /opt/xorcom_gui.tar.gz /var/www/html
cd /var/www/html
tar -vzxf xorcom_gui.tar.gz
\cp -Rf /opt/cpbx-config.php /var/www/html/admin
chown -R asterisk:asterisk /var/www/html/admin/cpbx-config.php
\cp -Rf /opt/index.php /var/www/html/index.php
chown -R asterisk:asterisk /var/www/html/index.php
\cp -Rf /opt/config.php /var/www/html/admin/config.php
chown -R asterisk:asterisk /var/www/html/admin/config.php
service httpd restart

log_info "Install is now 100% completed"

sleep 2
chvt ${ORIGCONSOLE}

